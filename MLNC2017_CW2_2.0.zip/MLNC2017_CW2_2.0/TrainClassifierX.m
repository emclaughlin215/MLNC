
function parameters = TrainClassifierX(input,output)

%% All implementation should be inside the function.

% For example: Method not using any parameters.
parameters = [];

end